//#include <stdio.h>
//#include <stdlib.h>
//
//void lingxing(int m);
//int main(void)
//{
//	lingxing(8);
//
//	return 0;
//}
//
//void lingxing(int m)
//{
//	int n = 1, i = 0, j = 0;
//	for (n = 1; n <= m; n++)
//	{
//		//����ո�
//		for (j = 0; j < m - n; j++)
//			putchar(' ');
//		//����Ǻ�
//		for (i = 1; i <= 2 * n - 1; i++)
//			putchar('*');
//		putchar('\n');
//	}
//
//	for (n = 1; n < m; n++)
//	{
//		for (j = 0; j < n; j++)
//			putchar(' ');
//		for (i = 0; i < 2*(m-n)-1; i++)
//			putchar('*');
//		putchar('\n');
//	}
//}