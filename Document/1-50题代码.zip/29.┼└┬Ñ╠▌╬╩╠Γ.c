//#include <stdio.h>
//
//int main(void)
//{
//	int f1 = 1, f2 = 2, f3;
//	printf("1 2 ");
//	int n = 3, m = 10;
//	for (n = 3; n <= m; n++)
//	{
//		f3 = f2 + f1;
//		f1 = f2;
//		f2 = f3;
//		printf("%d ", f3);
//	}
//
//	return 0;
//}
