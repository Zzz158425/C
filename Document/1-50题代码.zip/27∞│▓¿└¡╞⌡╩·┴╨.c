//#include <stdio.h>
//
//int main(void)
//{
//	int a[47] = { 0,1 };
//	//printf("0 1 ");
//	int i = 2;
//	for (i = 2; i < 10; i++)
//	{
//		a[i] = a[i - 1] + a[i - 2];
//		//printf("%d ", a[i]);
//	}
//	printf("\n%d ", a[i-1]);
//	return 0;
//}
