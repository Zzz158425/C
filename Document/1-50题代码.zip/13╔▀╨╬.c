//#include <stdio.h>
//#define N 6
//
//int main(void)
//{
//	int arr[N][N] = { 0 };
//	int x1 = 0, y1 = 0;
//	int x2 = 0, y2 = 0;
//	int n = 0, shu = 1;
//	while (1)
//	{
//		x1 = n, y1 = n;
//		x2 = x1, y2 = N - 1 - n;
//		int j;
//		for (j = y1; j <= y2; j++)
//			arr[x1][j] = shu++;
//
//		x1 = n + 1, y1 = j - 1;
//		x2 = N - 1 - n, y2 = y1;
//		for (j = x1; j <= x2; j++)
//			arr[j][y1] = shu++;
//
//		x1 = j - 1, y1 = y1 - 1;
//		x2 = x1, y2 = n;
//		for (j = y1; j >= y2; j--)
//			arr[x1][j] = shu++;
//
//		x1 = x1 - 1, y1 = n;
//		x2 = n + 1, y2 = y1;
//		for (j = x1; j >= x2; j--)
//			arr[j][y1] = shu++;
//
//		if (shu > N * N)
//			break;
//		n++;
//	}
//
//	int i, j;
//	for (i = 0; i < N; i++)
//	{
//		for (j = 0; j < N; j++)
//			printf("%4d", arr[i][j]);
//		putchar('\n');
//	}
//
//	return 0;
//}
