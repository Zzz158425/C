//#include <stdio.h>
//#include <stdlib.h>
//
//void dengyao(int m);
//int main(void)
//{
//	//int n = 1, m = 10, i = 0, j = 0;
//	//for (n = 1; n <= m; n++)
//	//{
//	//	//����ո�
//	//	for (j = 0; j < m - n; j++)
//	//		putchar(' ');
//	//	for (i = 1; i <= 2 * n - 1; i++)
//	//		putchar('*');
//	//	putchar('\n');
//	//}
//
//	dengyao(6);
//	dengyao(10);
//
//	return 0;
//}
//
//void dengyao(int m)
//{
//	int n = 1, i = 0, j = 0;
//	for (n = 1; n <= m; n++)
//	{
//		//����ո�
//		for (j = 0; j < m - n; j++)
//			putchar(' ');
//		//����Ǻ�
//		for (i = 1; i <= 2 * n - 1; i++)
//			putchar('*');
//		putchar('\n');
//	}
//}