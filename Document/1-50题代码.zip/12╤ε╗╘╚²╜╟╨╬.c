//#include <stdio.h>
//
//#define H 10
//#define L H+2
//
//int main(void)
//{
//	int a[H][L] = { 0 };
//	a[0][1] = 1;
//	int i, j;
//	for (i = 1; i < H; i++)
//		for (j = 1; j <= i + 1; j++)
//			a[i][j] = a[i - 1][j] + a[i - 1][j - 1];
//
//	for (i = 0; i < H; i++)
//	{
//		for (j = i; j < H; j++)
//			printf("   ");
//
//		for (j = 1; j <= i + 1; j++)
//			printf("%6d", a[i][j]);
//		putchar('\n');
//	}
//
//	return 0;
//}
