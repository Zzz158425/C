//#include <stdio.h>
//
//int main(void)
//{
//	int m = 5, n = 1;
//	int i, j;
//	for (n = 1; n <= m; n++)
//	{
//		//���ո�
//		for (i = 1; i <= m - n; i++)
//			putchar(' ');
//		//��ͼ��
//		char c = 64 + n;
//		for (j = 1 - n; j < n; j++)
//		{
//			if (j < 0)  putchar(c + j);
//			else putchar(c - j);
//		}
//			
//		putchar('\n');
//	}
//
//	return 0;
//}
