// /* //#include <stdio.h>

// //int main(void)
// //{
// //	int n = 1;
// //	int i = 0;
// //	char c = 'A';
// //	while (c <= 'Z')
// //	{
// //		//�����Ӧ��
// //		for (i = 0; i < n && c <= 'Z'; i++)
// //		{
// //			putchar(c);
// //			c++;
// //		}
// //			
// //		n++;
// //		putchar('\n');
// //	}
// //
// //	return 0;
// //}
