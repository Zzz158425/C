//#include <stdio.h>
//
//int len(char* p)
//{
//	if (*p == 0)
//		return 0;
//	return len(p + 1) + 1;
//}
//
//int main(void)
//{
//	printf("%d ", len("abcd"));
//	return 0;
//}