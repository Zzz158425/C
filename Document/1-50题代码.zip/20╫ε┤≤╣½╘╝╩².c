//#include <stdio.h>
//
//int main(void)
//{
//	int n1 = 12, n2 = 20;
//	int n = n1 > n2 ? n2 : n1;
//	int j, maxg = 0;
//	//for (j = 1; j <= n; j++)
//	//{
//	//	if (n1 % j == 0 && n2 % j == 0)
//	//	{
//	//		if (maxg < j)
//	//			maxg = j;
//	//		//printf("%d ", j);
//	//	}
//	//}
//	for (j = n; j >= 1; j--)
//		if (n1 % j == 0 && n2 % j == 0)
//			break;
//	printf("��� �� %d ", j);
//	return 0;
//}
