//#include <stdio.h>
////#define x 2.4
//double fn(int n, double x)
//{
//	if (0 == n)
//		return 1;
//	if (1 == n)
//		return x;
//	return ((2 * n - 1) * x - fn(n - 1, x) - (n - 1) * fn(n - 2, x)) / n;
//}
//
//int main(void)
//{
//	printf("%lf", fn(10, 3.2));
//	return 0;
//}
