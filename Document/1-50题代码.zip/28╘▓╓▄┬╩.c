//#include <stdio.h>
//#include <math.h>
//int main(void)
//{
//	double xs = 2.0 * sqrt(2.0) / 9801.0, sum = 0.0;
//	int n;
//	for (n = 0; n < 20; n++)
//	{
//		//double a = pow(4, n);
//		double a = 1.0;
//		int i;
//		for (i = 0; i < n; i++)
//			a *= 4;
//
//		double b = 1.0;
//		for (i = 1; i <= n; i++)
//			b *= n;
//
//		double c = 1103 + 26390 * n;
//
//		double d = b * b * b * b;
//
//		//double e = pow(396.0, 4 * n);
//		double e = 1.0;
//		for (i = 1; i <= 4 * n; i++)
//			e *= 396.0;
//
//		sum += (a * b * c) / (d * e);
//	}
//	printf("pai = %.10lf", 1.0 / (sum * xs));
//	return 0;
//}
