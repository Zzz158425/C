//#include <stdio.h>
//int main(void)
//{
//	int n = 0, i = 0, sum = 0;
//	for (i = 0; i < 6; i++)
//	{
//		n = n * 10 + 2;
//		sum += n;
//		printf("%d + ", n);
//	}
//	n = n * 10 + 2;
//	sum += n;
//	printf("%d == %d\n", n, sum);
//	return 0;
//}
