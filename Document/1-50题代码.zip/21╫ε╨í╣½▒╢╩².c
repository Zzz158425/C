//#include <stdio.h>
//
//int main(void)
//{
//	int n1 = 12, n2 = 20;
//	int maxn = n1 > n2 ? n1 : n2;
//	int j = maxn;
//	while (1)
//	{
//		if (j % n1 == 0 && j % n2 == 0)
//			break;
//		j += maxn;
//	}
//
//	printf("��С �� %d ", j);
//	return 0;
//}
