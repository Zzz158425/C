//#include <stdio.h>
//
//
//int main(void)
//{
//	int e = 0;
//	char* p = (char*)&e;
//	p[0] = 'A';
//	p[1] = 'B';
//	p[2] = 'C';
//	p[3] = 'D';
//	int i;
//	for (i = 0; i < 4; i++)
//		printf("%c ", ((char*)&e)[i]);//p[i]
//
//	return 0;
//}