//#include <stdio.h>
//
//int main(void)
//{
//	int az = -12321, af = 0;
//	int we = az;
//	while (az != 0)
//	{
//		int w = az % 10;
//		af = af * 10 + w;
//		az /= 10;
//	}
//
//	if (af == we)
//		printf("%d �ǻ���", we);
//	else
//		printf("%d ������", we);
//	return 0;
//}