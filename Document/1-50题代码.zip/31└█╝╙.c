//#include <stdio.h>
//
//int f(int n)
//{
//	if (1 == n)
//		return 1;
//	return n + f(n - 1);
//}
//
//int main(void)
//{
//	printf("%d", f(5));
//	return 0;
//}
