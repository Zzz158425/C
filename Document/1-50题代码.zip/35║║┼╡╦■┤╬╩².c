//#include <stdio.h>
//
//int f(int n)
//{
//	if (1 == n)
//		return 1;
//	return 2 * f(n - 1) + 1;
//}
//
//int main(void)
//{
//	printf("%d", f(1));
//	return 0;
//}
