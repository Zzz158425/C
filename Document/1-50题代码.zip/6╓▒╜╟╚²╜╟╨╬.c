//#include <stdio.h>
//#include <stdlib.h>
//
//void zhijiao(int m);
//int main(void)
//{
//	//int n = 1, m = 8, i = 0;
//	//for (n = 1; n <= m; n++)
//	//{
//	//	for (i = 1; i <= 2 * n - 1; i++)
//	//		putchar('*');
//	//	putchar('\n');
//	//}
//
//	zhijiao(5);
//
//	return 0;
//}
//
//void zhijiao(int m)
//{
//	int n = 1, i = 0;
//	for (n = 1; n <= m; n++)
//	{
//		for (i = 1; i <= 2 * n - 1; i++)
//			putchar('*');
//		putchar('\n');
//	}
//}