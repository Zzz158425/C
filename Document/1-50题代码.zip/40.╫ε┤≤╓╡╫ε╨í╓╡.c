//#include <stdio.h>
//
//void get(int* a, int len, int*max, int *min)
//{
//	int i;
//	*max = a[0], *min = a[0];
//	for (i = 1; i < len; i++)
//	{
//		if (*max < a[i])
//		{
//			*max = a[i];
//		}
//		if (*min > a[i])
//		{
//			*min = a[i];
//		}
//	}
//}
//
//int main(void)
//{
//	int a[10] = { 3,2,6,4,7,5,3,1,7,5 };
//	int max = 0, min = 0;
//	get(a, 10, &max, &min);
//	printf("max = %d, min = %d", max, min);
//	return 0;
//}