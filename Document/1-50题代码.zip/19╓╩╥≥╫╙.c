//#include <stdio.h>
//#include <math.h>
//
//int prime(int n)
//{
//	if (0 == n || 1 == n)
//		return 0;
//	if (2 == n)
//		return 1;
//	int j, m=(int)sqrt(n);
//	for (j = 2; j <= m; j++)
//		if (n % j == 0)
//			return 0;
//	return 1;
//}
//
//int main(void)
//{
//	int n = 9, j;
//	int m = (int)sqrt(n);
//	for (j = 1; j <= m; j++)
//	{
//		if (n % j == 0)
//		{
//			if (prime(j))
//				printf("%d ", j);
//			if (j != n/j && prime(n/j))
//				printf("%d ", n/j);
//		}
//	}
//	return 0;
//}
////12 ������  1 2 3 4 6 12
////20 ������  1 2 4 5 10 20
////��ͬ������  1 2 4
////���Լ��  4