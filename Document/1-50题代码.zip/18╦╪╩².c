//#include <stdio.h>
//#include <math.h>
//int prime(int n)
//{
//	int j;
//	if (0 == n || 1 == n)
//		return 0;
//	if (2 == n)
//		return 1;
//	int m = (int)sqrt(n);
//	for (j = 2; j <= m; j++)
//		if (n % j == 0)
//			return 0;
//	return 1;
//}
//
//int main(void)
//{
//	int n, sum = 0;
//	for (n = 100; n <= 999; n++)
//	{
//		if (1 == prime(n))
//		{
//			sum += n;
//			printf("%d ", n);
//		}
//	}
//	printf("\n%d", sum);
//	return 0;
//}