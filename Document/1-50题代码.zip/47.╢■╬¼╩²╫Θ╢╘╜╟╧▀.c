//
//#include <stdio.h>
//
//int Sum(int(*arr)[3][3], int hang, int lie)
//{
//    int i, j, sum = 0;
//    for (i = 0; i < hang; i++)
//    {
//        for (j = 0; j < lie; j++)
//        {
//            if (i == j || i + j == hang - 1)
//            {
//                sum += (*arr)[i][j];
//            }
//        }
//    }
//    return sum;
//}
//
//
//int main()
//{
//    int a[3][3] = { {1, 2, 3},
//                    {4, 5, 6},
//                    {7, 8, 9} };
//
//    printf("%d\n", Sum(&a, 3, 3));
//
//    return 0;
//}