//#include <stdio.h>
//int fun1(int* a) { return 0; }
//int fun2(int* a) { return 0; }
//int fun3(int* a) { return 0; }
//int (*arr[3])(int*) = {fun1, fun2, fun3};
//int (*(*fun4(int* a))[3])(int*)
//{
//	return &arr;
//}
//
//int main(void)
//{
//	int (*(*(*pf)(int*))[3])(int*) = fun4;
//
//
//	return 0;
//}