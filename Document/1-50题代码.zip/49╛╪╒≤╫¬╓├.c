//#include <stdio.h>
//#define hang 3
//#define lie 2
//
//void ZhuanZhi(int arr[hang][lie], int crr[lie][hang])
//{
//    int i, j;
//    for (i = 0; i < hang; i++)
//    {
//        for (j = 0; j < lie; j++)
//        {
//            crr[j][i] = arr[i][j];
//        }
//    }
//}
//int main()
//{
//    int arr[hang][lie] = { {1,2},{3,4},{5,6} };
//    int crr[lie][hang] = { 0 };
//    ZhuanZhi(arr, crr);
//
//    int i, j;
//    for (i = 0; i < lie; i++)
//    {
//        for (j = 0; j < hang; j++)
//        {
//            printf("%d ", crr[i][j]);
//        }
//        putchar('\n');
//    }
//
//    return 0;
//}