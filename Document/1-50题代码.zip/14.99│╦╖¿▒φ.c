//#include <stdio.h>
//
//int main(void)
//{
//	int i, j;
//	//for (i = 1; i <= 9; i++)
//	//{
//	//	for (j = 1; j <= 9; j++)
//	//		if (i >= j)
//	//			printf("%dx%d=%2d ", i, j, i * j);
//	//	putchar('\n');
//	//}
//	//for (i = 1; i <= 9; i++)
//	//{
//	//	for (j = 8; j >= i; j--)
//	//		printf("       ");
//	//	for (j = 1; j <= 9; j++)
//	//		if (i >= j)
//	//			printf("%dx%d=%2d ", i, j, i * j);
//	//	putchar('\n');
//	//}
//	//putchar('\n');
//	//for (i = 1; i <= 9; i++)
//	//{
//	//	for (j = 1; j < i; j++)
//	//		printf("       ");
//	//	for (j = 1; j <= 9; j++)
//	//		if (i <= j)
//	//			printf("%dx%d=%2d ", i, j, i * j);
//	//	putchar('\n');
//	//}
//	//for (i = 1; i <= 9; i++)
//	//{
//	//	for (j = 1; j <= 9; j++)
//	//		if (i <= j)
//	//			printf("%dx%d=%2d ", i, j, i * j);
//	//	putchar('\n');
//	//}
//
//	for (i = 1; i <= 9; i++)
//	{
//		for (j = 1; j <= 9; j++)
//			if (i + j <= 10)
//				printf("%dx%d=%2d ", i, j, i * j);
//		putchar('\n');
//	}
//
//	return 0;
//}
