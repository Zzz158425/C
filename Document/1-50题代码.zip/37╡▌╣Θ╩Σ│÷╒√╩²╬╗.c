//#include <stdio.h>
//
//void f(int n)
//{
//	if (0 == n)
//		return;
//	
//	f(n / 10);
//	printf("%d ", n % 10);
//}
//
//int main(void)
//{
//	f(12345);
//	return 0;
//}