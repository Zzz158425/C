//#include <stdio.h>
//#include <math.h>
//int main(void)
//{
//	int n = 2;
//	//ѭ��2~100
//	while (n <= 1000)
//	{
//		//�ۼ�������
//		int sum = 0, j = 1;
//		int nn = sqrt(n);
//		for (j = 2; j <= nn; j++)
//			if (n % j == 0)
//			{
//				sum += j;
//				if (j != n/j)
//					sum += n / j;
//			}
//				
//		sum += 1;
//		//�ж�����
//		if (sum == n)
//			printf("%d ������\n", n);
//		n++;
//	}
//	return 0;
//}
