//#include <stdio.h>
//
//void swap(int a[10], int len)
//{
//	int i = 0, j = len - 1;
//	while (i < j)
//	{
//		//����
//		int c = a[i];
//		a[i] = a[j];
//		a[j] = c;
//		//�仰
//		i++, j--;
//	}
//}
//
//void swap1(int a[10], int len)
//{
//	int* pq = &a[0], * ph = a + (len-1);
//	while (pq < ph)
//	{
//		//����
//		int c = *pq;
//		*pq = *ph;
//		*ph = c;
//		//�仰
//		pq++, ph--;
//	}
//}
//
//int main(void)
//{
//	int a[9] = { 0,1,2,3,4,5,6,7,8 };
//	swap1(a, 9);
//	return 0;
//}