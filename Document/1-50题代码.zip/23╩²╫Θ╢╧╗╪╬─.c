//#include <stdio.h>
//
//int main(void)
//{
//	int n = 1, nn = n;
//	int arr[10] = { 0 }, in = 0;
//	while (n != 0)
//	{
//		arr[in] = n % 10;
//		in++;
//		n /= 10;
//	}
//
//	int j = in - 1, i = 0;
//	while (i < j)
//	{
//		if (arr[i] != arr[j])
//			break;
//		i++;
//		j--;
//	}
//	if (i >= j)
//	{
//		printf("%d�ǻ���\n", nn);
//	}
//	else
//	{
//		printf("%d���ǻ���\n", nn);
//	}
//	return 0;
//}
