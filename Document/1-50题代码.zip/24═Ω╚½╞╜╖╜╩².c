//#include <stdio.h>
//#include <math.h>
//int IsSqrt(int n)
//{
//	int x = (int)sqrt(n);
//	if (x * x == n)
//		return 1;
//	return 0;
//}
//int main(void)
//{
//	int n = 0;
//	for (n = 0; n < 7225; n++)
//	{
//		if (1 == IsSqrt(n + 100) && 1 == IsSqrt(n + 268))
//		{
//			printf("%d ������Ҫ�ҵ�\n", n);
//		}
//	}
//	return 0;
//}
