//#include <stdio.h>
//
//int main(void)
//{
//	int az = 123456, w = 0, af = 0;
//	printf("%d\n", az);
//	while (az != 0)
//	{
//		w = az % 10;
//		af = w + af * 10;
//		az /= 10;
//	}
//	az = af;
//	printf("%d\n", az);
//	return 0;
//}
