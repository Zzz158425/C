//#include <stdio.h>
//#include <stdlib.h>
//#include <time.h>
//#include <windows.h>
//
//char str[15][42] = {
//	"       *********         *********       ",
//	"    ***************   ***************    ",
//	"  ****************** ******************  ",
//	" *************************************** ",
//	"*****************************************",
//	"*****************************************",
//	" *************************************** ",
//	"  *************************************  ",
//	"    *********************************    ",
//	"      *****************************      ",
//	"        *************************        ",
//	"           *******************           ",
//	"              *************              ",
//	"                 *******                 ",
//	"                   ***                   " };
//
//void Goto(int hang, int lie)
//{
//	COORD cd = {lie, hang};
//	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), cd);
//}
//
//void Dong(int m, char c)
//{
//	int n = 0;
//	while (n++ < m)
//	{
//		int hang = rand() % 15;
//		int lie = rand() % 42;
//
//		if ('*' != str[hang][lie])
//			continue;
//
//		Goto(hang, lie);
//		putchar(c);
//		Sleep(10);
//	}
//}
//
//int main(void)
//{
//	srand((unsigned int)time(NULL));
//	Dong(300, 'o');
//	Dong(500, 'l');
//	Dong(600, '#');
//	getchar();
//	return 0;
//}