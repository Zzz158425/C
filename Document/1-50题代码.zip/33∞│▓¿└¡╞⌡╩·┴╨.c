//#include <stdio.h>
//
//int f(int n)
//{
//	if (1 == n )
//		return 1;
//	if (2 == n)
//		return 2;
//	return f(n - 1) + f(n - 2);
//}
//
//int main(void)
//{
//	printf("%d", f(8));
//	return 0;
//}
