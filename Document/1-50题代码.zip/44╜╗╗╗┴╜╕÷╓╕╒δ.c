//#include <stdio.h>
//
//void swap(int* *paa, int**pbb)
//{
//	int* c = *paa;
//	*paa = *pbb;
//	*pbb = c;
//}
//
//int main(void)
//{
//	int a = 2, b = 3;
//	int* pa = &a, * pb = &b;
//	printf("%d  %d\n", *pa, *pb);
//	swap(&pa, &pb);
//	printf("%d  %d\n", *pa, *pb);
//	return 0;
//}