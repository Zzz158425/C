//#include <stdio.h>
//
//void f(int n, char L, char M, char R)
//{
//	if (1 == n)
//		printf("%c -> %c\n", L, R);
//	else
//	{
//		f(n - 1, L, R, M);
//		printf("%c -> %c\n", L, R);
//		f(n - 1, M, L, R);
//	}
//}
//
//int main(void)
//{
//	f(4, 'L', 'M', 'R');
//	return 0;
//}