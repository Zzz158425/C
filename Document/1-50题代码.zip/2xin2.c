//#include <stdio.h>
//void Xin_5(void)
//{
//	for (float y = 2.5f; y > -1.5f; y -= 0.1f)
//	{
//		for (float x = -1.5f; x < 1.5f; x += 0.05f)
//		{
//			float a = x * x + y * y - 1;
//			float n = a * a * a - x * x * y * y * y; //���� ��֪��������ô�������
//			putchar(n <= 0.0f ? '*' : ' '); //�� n ��ֵС�ڵ��� 0�����*����������ո�
//		}
//		putchar('\n');
//	}
//}
//int main(void)
//{
//	int gui[15] = { 7,4,2,1,0,0,1,4,7,10,13,15,17,19,20 };
//	int zhonggui[3] = { 9,3,1 };
//	int xing[3] = { 9, 15, 18 };
//	int i = 0, j = 0;
//	//int n = 41 - gui[i] * 2 - zhonggui[i];
//	for (i = 0; i < 3; i++)
//	{
//		for (j = 0; j < gui[i]; j++)       putchar(' ');
//		for (j = 0; j < xing[i]; j++)      putchar('*');
//		for (j = 0; j < zhonggui[i]; j++)  putchar(' ');
//		for (j = 0; j < xing[i]; j++)      putchar('*');
//		putchar('\n');
//	}
//
//	for (i = 3; i < 15; i++)
//	{
//		for (j = 0; j < gui[i]; j++)           putchar(' ');
//		for (j = 0; j < 41 - gui[i] * 2; j++)  putchar('*');
//		putchar('\n');
//	}
//	Xin_5();
//	getchar();
//	return 0;
//}