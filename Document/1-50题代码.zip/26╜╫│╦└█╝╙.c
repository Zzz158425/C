//#include <stdio.h>
//
//int main(void)
//{
//	int n = 1, i = 1, sum = 0;
//	for (i = 1; i <= 4; i++)
//	{
//		n *= i;
//		sum += n;
//		printf("%d! + ", i);
//		/*if (i == 5)
//			printf("%d! ", i);
//		else
//			printf("%d! + ", i);*/
//	}
//	n *= i;
//	sum += n;
//	printf("%d! == %d", i, sum);
//	return 0;
//}
