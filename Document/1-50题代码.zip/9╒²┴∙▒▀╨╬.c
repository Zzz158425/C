//#include <stdio.h>
//#include <stdlib.h>
//#include <math.h>
//
//void liubianxing(int m);
//int main(void)
//{
//	liubianxing(10);
//
//	return 0;
//}
//
//void liubianxing(int m)
//{
//	int n, i, j;
//	int t = m;
//	for (n = 1 - m; n < m; n++)
//	{
//		for (i = 0; i < abs(n); i++)
//			putchar(' ');
//		for (j = 0; j < t; j++)
//			putchar('*');
//		if (n < 0)
//			t += 2;
//		else
//			t -= 2;
//
//		putchar('\n');
//	}
//}