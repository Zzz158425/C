//#include <stdio.h>
//
//int f(int n)
//{
//	if (1 == n)
//		return 1;
//	else
//		return n * f(n - 1);
//}
//
//int main(void)
//{
//	printf("%d", f(8));
//	return 0;
//}
