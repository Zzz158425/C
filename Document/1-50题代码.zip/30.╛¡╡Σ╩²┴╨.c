//#include <stdio.h>
//
//int main(void)
//{
//	int n = 1, fh = 1, fz = 0,fmq = 0,fmh = 1;
//	double sum = 0.0;
//	for (n = 1; n <= 10; n++)
//	{
//		fh = -fh;
//		fz += n;
//		fmq = 2 * n + 1;
//		fmh *= n;
//		sum += (double)(fh * fz) / (double)(fmq * fmh);
//	}
//	printf("%lf", sum);
//	return 0;
//}
