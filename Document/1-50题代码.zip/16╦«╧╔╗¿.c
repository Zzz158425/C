//#include <stdio.h>
//#include <math.h>
//int main(void)
//{
//	
//	int i, ge, shi, bai;
//	for (i = 100; i <= 999; i++)
//	{
//		ge = i % 10;
//		shi = i / 10 % 10;
//		bai = i / 100;
//		//if (ge * ge * ge + shi * shi * shi + bai * bai * bai == i)
//		if ((int)(pow(ge, 3) + pow(shi, 3) + pow(bai, 3)) == i)
//			printf("%d ", i);
//	}
//	return 0;
//}
